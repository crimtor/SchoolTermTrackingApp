package com.example.schoolapp.schoolapp;

import android.content.ContentValues;
import android.content.Context;

/**
 * Created by Shawn T Fox
 * For WGU - Mobile Application Development
 *  Course C196
 *  Student ID#000545644
 */

public class ObjectMentor {

    public int courseId;
    public int mentorId;
    public String mentorName;
    public String mentorEmail;
    public String mentorPhone;

    public ObjectMentor(){}


}
